package com.example.quartzdemo;

import com.example.quartzdemo.entity.ScheduledJob;
import com.example.quartzdemo.repository.ScheduledJobRepository;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DynamicJobSchedulerService {

    @Autowired
    private Scheduler scheduler;

    @Autowired
    private ScheduledJobRepository jobRepository;

    // Maintain a map of currently scheduled jobs
    private Map<Long, String> scheduledJobs = new HashMap<>();

    @PostConstruct
    public void scheduleAllJobs() throws Exception {
        refreshJobs();
    }

    @Scheduled(fixedDelay = 60000) // Check every 60 seconds for updates
    public void refreshJobs() throws Exception {
        List<ScheduledJob> jobs = jobRepository.findByIsActiveTrue();
        for (ScheduledJob job : jobs) {
            String existingCron = scheduledJobs.get(job.getId());

            if (existingCron == null || !existingCron.equals(job.getCronExpression())) {
                rescheduleJob(job);
            }
        }
        removeInactiveJobs(jobs);
    }

    private void rescheduleJob(ScheduledJob job) throws Exception {
        scheduler.deleteJob(new JobKey(job.getJobName(), job.getJobGroup()));

        Class<? extends Job> jobClass = (Class<? extends Job>) Class.forName(job.getJobClassName());
        JobDetail jobDetail = JobBuilder.newJob(jobClass)
                .withIdentity(job.getJobName(), job.getJobGroup())
                .build();

        Trigger trigger = TriggerBuilder.newTrigger()
                .withIdentity(job.getJobName() + "Trigger", job.getJobGroup())
                .withSchedule(CronScheduleBuilder.cronSchedule(job.getCronExpression()))
                .forJob(jobDetail)
                .build();

        scheduler.scheduleJob(jobDetail, trigger);
        scheduledJobs.put(job.getId(), job.getCronExpression()); // Update the cache
    }

    private void removeInactiveJobs(List<ScheduledJob> activeJobs) throws SchedulerException {
        Map<Long, ScheduledJob> activeJobMap = new HashMap<>();
        for (ScheduledJob job : activeJobs) {
            activeJobMap.put(job.getId(), job);
        }

        for (Map.Entry<Long, String> entry : scheduledJobs.entrySet()) {
            if (!activeJobMap.containsKey(entry.getKey())) {
                scheduler.deleteJob(new JobKey(activeJobMap.get(entry.getKey()).getJobName(), 
                                               activeJobMap.get(entry.getKey()).getJobGroup()));
                scheduledJobs.remove(entry.getKey());
            }
        }
    }

    public void runJobNow(String jobName, String jobGroup) throws Exception {
        ScheduledJob job = jobRepository.findByJobNameAndJobGroup(jobName, jobGroup);
        if (job != null) {
            Class<? extends Job> jobClass = (Class.forName(job.getJobClassName()));

            JobDetail jobDetail = JobBuilder.newJob(jobClass)
                    .withIdentity(job.getJobName(), job.getJobGroup())
                    .build();

            Trigger trigger = TriggerBuilder.newTrigger()
                    .withIdentity(job.getJobName() + "_manualTrigger", job.getJobGroup())
                    .startNow()
                    .build();

            scheduler.scheduleJob(jobDetail, trigger);
        } else {
            System.out.println("Job with name " + jobName + " and group " + jobGroup + " not found.");
        }
    }
}
