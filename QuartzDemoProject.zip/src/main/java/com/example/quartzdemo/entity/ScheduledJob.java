package com.example.quartzdemo.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "scheduled_jobs")
public class ScheduledJob {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String jobName;
    private String jobGroup;
    private String jobClassName;
    private String cronExpression;
    private Boolean isActive;

    @Column(name = "last_updated")
    private LocalDateTime lastUpdated;

    // Getters and setters
}
