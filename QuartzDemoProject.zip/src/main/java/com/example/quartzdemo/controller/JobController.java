package com.example.quartzdemo.controller;

import com.example.quartzdemo.DynamicJobSchedulerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/jobs")
public class JobController {

    @Autowired
    private DynamicJobSchedulerService jobSchedulerService;

    @PostMapping("/run-now")
    public String runJobNow(@RequestParam String jobName, @RequestParam String jobGroup) {
        try {
            jobSchedulerService.runJobNow(jobName, jobGroup);
            return "Job triggered successfully";
        } catch (Exception e) {
            return "Error triggering job: " + e.getMessage();
        }
    }
}
